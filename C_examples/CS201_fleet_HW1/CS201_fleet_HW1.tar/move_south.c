/*Pre-processor directives*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int move_south(int* x)
{
  *x = *x + 1;
  
  return 1; 
}
