/*Pre-processor directives*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int move_north(int* x)
{
   *x = *x - 1;

   return 1;
}
